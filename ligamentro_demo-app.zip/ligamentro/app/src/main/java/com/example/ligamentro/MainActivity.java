package com.example.ligamentro;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_MEDIA_AUDIO;
import static android.Manifest.permission.READ_MEDIA_IMAGES;
import static android.Manifest.permission.READ_MEDIA_VIDEO;
import static android.Manifest.permission.RECORD_AUDIO;

import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    private SurfaceView surfaceView;
    private MediaRecorder mediaRecorder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ActivityCompat.requestPermissions(this,
                new String[]{CAMERA,
                        READ_MEDIA_VIDEO,
                        READ_MEDIA_IMAGES,
                        READ_MEDIA_AUDIO,
                        RECORD_AUDIO},
                PackageManager.PERMISSION_GRANTED);

        surfaceView = findViewById(R.id.surfaceView);

        mediaRecorder = new MediaRecorder(this);

    }


    public void buttonStartRecording(View view){
        StorageManager storageManager = (StorageManager) getSystemService(STORAGE_SERVICE);
        StorageVolume storageVolume = storageManager.getStorageVolumes().get(0);
        File fileVideo = new File(storageVolume.getDirectory().getPath() +
                "/Download/" +
                System.currentTimeMillis() + ".mp4");
        mediaRecorder.setVideoSource(MediaRecorder.VideoSource.CAMERA);
        mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        mediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);

        mediaRecorder.setVideoEncoder(MediaRecorder.VideoEncoder.DEFAULT);
        mediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);

        mediaRecorder.setOutputFile(fileVideo.getPath());

        mediaRecorder.setMaxDuration(5000); //5seconds
        mediaRecorder.setMaxFileSize(5000000); //5MB

        mediaRecorder.setPreviewDisplay(surfaceView.getHolder().getSurface());

        try {
            mediaRecorder.prepare();
        } catch (IOException e) {
            Toast.makeText(this, e.toString(), Toast.LENGTH_LONG).show();
        }

        mediaRecorder.start();

    }
    public void buttonStopRecording(View view) {

        mediaRecorder.stop();
        mediaRecorder.release();

    }

}